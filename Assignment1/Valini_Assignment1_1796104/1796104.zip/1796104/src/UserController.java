
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserController")
public class UserController extends HttpServlet {
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//create object user get the data
		User user= new User();
		
	     user.setUserID(request.getParameter("userID"));
	     user.setUsername(request.getParameter("username"));
	     user.setPassword(request.getParameter("password"));
	     user.setEmail(request.getParameter("email"));
	     user.setCity(request.getParameter("city"));
	     user.setZipCode(request.getParameter("zipCode"));
		String result="";
		PrintWriter pw = response.getWriter();
	
		//save the text file
		try {
		String file =  "userdata.txt";
	    
        FileWriter filewriter = new FileWriter(file, false);
        filewriter.write("Information saved successfully for the userID : "+ user.getUserID());
        filewriter.write("\r\n"); 
        filewriter.write("Username: "+user.getUsername());
        filewriter.write("\r\n"); 
        filewriter.write("Password: " +user.getPassword());
        filewriter.write("\r\n");
        filewriter.write("Email: "+user.getEmail());
        filewriter.write("\r\n");
        filewriter.write("City: "+user.getCity());
        filewriter.write("\r\n");
        filewriter.close();
        }
		catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
        
        //read the file
        // The name of the file to open.
        String fileName = "userdata.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                //System.out.println(line);
            	pw.write("<p>" + line + "</p>");
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            
        }
        
        
    }
	
		


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
